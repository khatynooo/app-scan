package ir.khatynoo.naghshjahan

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast

class MainActivity : Activity() {
    private val teal = Color.rgb(15, 118, 110)
    private val ink = Color.rgb(20, 43, 48)
    private val muted = Color.rgb(100, 121, 124)
    private val pale = Color.rgb(242, 248, 247)
    // Visible history for this app session and a separate one-time queue for the website picker.
    private val files = mutableListOf<Uri>()
    private val pendingSharedUris = mutableListOf<Uri>()
    private var uploaderOpen = false
    private var webView: WebView? = null
    private var pendingFileCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val pickerRequestCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncoming(intent)
        renderHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val oldCount = files.size
        handleIncoming(intent)
        if (uploaderOpen) {
            val added = files.size - oldCount
            Toast.makeText(this, if (added > 0) "$added فایل جدید دریافت شد؛ در انتخاب فایل صفحه ارسال قابل انتخاب است." else "فایل تکراری بود یا فایلی دریافت نشد.", Toast.LENGTH_LONG).show()
        } else {
            renderHome()
        }
    }

    private fun handleIncoming(incoming: Intent?) {
        if (incoming == null) return
        val incomingUris: List<Uri> = when (incoming.action) {
            Intent.ACTION_SEND -> buildList {
                getSingleSharedUri(incoming)?.let { add(it) }
                incoming.data?.let { add(it) }
                incoming.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { add(it) }
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> getMultipleSharedUris(incoming)
            else -> emptyList()
        }
        incomingUris.distinct().forEach {
            if (!files.contains(it)) files.add(it)
            if (!pendingSharedUris.contains(it)) pendingSharedUris.add(it)
        }
    }


    @Suppress("DEPRECATION")
    private fun getSingleSharedUri(incoming: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else incoming.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    @Suppress("DEPRECATION")
    private fun getMultipleSharedUris(incoming: Intent): List<Uri> {
        val list: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
            incoming.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            incoming.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
        }
        return list ?: incoming.clipData?.let { clip ->
            (0 until clip.itemCount).map { clip.getItemAt(it).uri }
        } ?: emptyList()
    }

    private fun renderHome() {
        uploaderOpen = false
        webView = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(24))
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(pale)
        }
        val logo = TextView(this).apply {
            text = "ن"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(teal)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) }
        }
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandText.addView(label("نقش جهان", 18f, ink, true))
        brandText.addView(label("مرکز هوشمند ارسال فایل چاپ", 12f, muted, false))
        brand.addView(logo)
        brand.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(brand)

        val title = label("فایل‌هات رو برای چاپ بفرست", 25f, ink, true)
        title.setPadding(0, dp(28), 0, dp(8))
        body.addView(title)
        body.addView(label("از گالری یا فایل‌منیجر اشتراک‌گذاری کن، یا فایل‌ها را همین‌جا انتخاب کن.", 15f, muted, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(247, 250, 249))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
        }
        card.addView(label(if (files.isEmpty()) "هنوز فایلی انتخاب نشده" else "${files.size} فایل آماده بررسی", 17f, ink, true))
        card.addView(label("فایل‌ها تا وقتی خودت ادامه ندهی ارسال نمی‌شوند.", 13f, muted, false).apply {
            setPadding(0, dp(6), 0, dp(12))
        })
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(listBox)
        body.addView(card)

        val pickButton = Button(this).apply {
            text = "انتخاب فایل از گوشی"
            isAllCaps = false
            setTextColor(teal)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(226, 243, 240)))
            setOnClickListener { launchDocumentPicker() }
        }
        body.addView(pickButton, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(16) })

        val sendButton = Button(this).apply {
            text = "اتصال به سامانه ارسال چاپ  ↗"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal))
            setOnClickListener { openUploader() }
        }
        body.addView(sendButton, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) })
        body.addView(label("در صفحه ارسال، فایل‌ها از طریق سامانه فعلی نقش جهان آپلود می‌شوند. بررسی و تأیید نهایی با خودت است.", 12f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })

        if (files.isEmpty()) {
            listBox.addView(label("PDF · JPG/PNG · Word/Excel · فایل‌های دیگر", 12f, muted, false))
        } else {
            files.toList().forEachIndexed { index, uri ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    setBackgroundColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) }
                }
                val info = fileInfo(uri)
                val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                txt.addView(label(info.first, 14f, ink, true))
                txt.addView(label(info.second, 11f, muted, false))
                row.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
                val remove = Button(this).apply {
                    text = "حذف"
                    isAllCaps = false
                    setOnClickListener {
                        files.remove(uri)
                        pendingSharedUris.remove(uri)
                        renderHome()
                    }
                }
                row.addView(remove)
                listBox.addView(row)
            }
        }

        scroll.addView(body)
        root.addView(scroll)
        setContentView(root)
    }

    private fun launchDocumentPicker() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(pick, 100)
    }

    private fun openUploader() {
        uploaderOpen = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(12), dp(6))
            setBackgroundColor(pale)
        }
        val back = Button(this).apply {
            text = "بازگشت"
            isAllCaps = false
            setTextColor(teal)
            setOnClickListener { renderHome() }
        }
        toolbar.addView(back)
        toolbar.addView(label("ارسال امن فایل برای چاپ", 16f, ink, true), LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = dp(10)
        })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        val web = WebView(this)
        webView = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: return true
                return if (host == "khatynoo.ir" || host.endsWith(".khatynoo.ir")) {
                    false
                } else {
                    Toast.makeText(this@MainActivity, "برای امنیت، فقط صفحه‌های نقش جهان در این بخش باز می‌شوند.", Toast.LENGTH_LONG).show()
                    true
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                progress.progress = newProgress
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                if (files.isNotEmpty()) {
                    // Pass newly shared files to the existing site uploader once, while keeping
                    // the session list visible if the user returns to the app home screen.
                    val shared = pendingSharedUris.toTypedArray()
                    pendingSharedUris.clear()
                    pendingFileCallback = null
                    filePathCallback.onReceiveValue(shared)
                    return true
                }
                return try {
                    val choose = fileChooserParams.createIntent().apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    }
                    startActivityForResult(choose, pickerRequestCode)
                    true
                } catch (_: Exception) {
                    pendingFileCallback = null
                    filePathCallback.onReceiveValue(null)
                    Toast.makeText(this@MainActivity, "انتخاب‌گر فایل در دسترس نیست؛ دوباره تلاش کن.", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        root.addView(toolbar)
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        web.loadUrl("https://khatynoo.ir/print-upload/")
    }

    @Deprecated("Activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerRequestCode) {
            val callback = pendingFileCallback
            pendingFileCallback = null
            if (callback != null && resultCode == RESULT_OK && data != null) {
                val picked = mutableListOf<Uri>()
                data.clipData?.let { clip -> for (i in 0 until clip.itemCount) picked.add(clip.getItemAt(i).uri) }
                if (picked.isEmpty()) data.data?.let { picked.add(it) }
                callback.onReceiveValue(picked.distinct().toTypedArray())
            } else {
                callback?.onReceiveValue(null)
            }
            return
        }
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val picked = mutableListOf<Uri>()
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) picked.add(clip.getItemAt(i).uri) }
            if (picked.isEmpty()) data.data?.let { picked.add(it) }
            picked.forEach {
                if (!files.contains(it)) files.add(it)
                if (!pendingSharedUris.contains(it)) pendingSharedUris.add(it)
            }
            renderHome()
        }
    }

    @Deprecated("Back navigation compatibility")
    override fun onBackPressed() {
        if (uploaderOpen) {
            val web = webView
            if (web != null && web.canGoBack()) web.goBack() else renderHome()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        webView?.destroy()
        webView = null
        super.onDestroy()
    }

    private fun fileInfo(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment ?: "فایل انتخاب‌شده"
        var size = "آماده بررسی"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = formatSize(c.getLong(si))
                }
            }
        } catch (_: Exception) {}
        return name to size
    }

    private fun formatSize(n: Long): String = when {
        n >= 1024L * 1024L -> String.format("%.1f مگابایت", n / (1024.0 * 1024.0))
        n >= 1024L -> String.format("%.0f کیلوبایت", n / 1024.0)
        else -> "$n بایت"
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
