plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.khatynoo.naghshjahan"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.khatynoo.naghshjahan"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
